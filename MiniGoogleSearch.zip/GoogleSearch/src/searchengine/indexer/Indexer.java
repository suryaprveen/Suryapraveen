/**  
 * 
 * Copyright: Copyright (c) 2004 Carnegie Mellon University
 * 
 * This program is part of an implementation for the PARKR project which is 
 * about developing a search engine using efficient Datastructures.
 * 
 * Modified by Mahender on 12-10-2009
 */

package searchengine.indexer;

import java.io.FileInputStream;
import java.io.FileOutputStream;
import java.io.IOException;
import java.io.ObjectInputStream;
import java.io.ObjectOutputStream;
import java.io.Serializable;
import java.net.URL;
import java.util.HashMap;
import java.util.Iterator;
import java.util.Map;
import java.util.Map.Entry;
import java.util.Vector;

//import com.sun.org.apache.xpath.internal.compiler.Keywords;

import searchengine.dictionary.AVLDictionary;
import searchengine.dictionary.BSTDictionary;
import searchengine.dictionary.DictionaryInterface;
import searchengine.dictionary.HashDictionary;
import searchengine.dictionary.ListDictionary;
import searchengine.dictionary.MyHashDictionary;
import searchengine.dictionary.ObjectIterator;
import searchengine.element.PageElementInterface;
import searchengine.element.PageWord;

/**
 * Web-indexing objects.  This class implements the Indexer interface
 * using a list-based index structure.

A Hash Map based implementation of Indexing 

 */
/**  
 * 
 * Copyright: Copyright (c) 2004 Carnegie Mellon University
 * 
 * This program is part of an implementation for the PARKR project which is 
 * about developing a search engine using efficient Datastructures.
 * 
 * Modified by Mahender on 12-10-2009
 */

import java.io.FileInputStream;
import java.io.FileOutputStream;
import java.io.IOException;
import java.net.URL;
import java.util.HashMap;
import java.util.Vector;

import searchengine.dictionary.AVLDictionary;
import searchengine.dictionary.BSTDictionary;
import searchengine.dictionary.DictionaryInterface;
import searchengine.dictionary.HashDictionary;
import searchengine.dictionary.ListDictionary;
import searchengine.dictionary.MyHashDictionary;
import searchengine.dictionary.ObjectIterator;
import searchengine.element.PageElementInterface;
import searchengine.element.PageWord;

/**
 * Web-indexing objects. This class implements the Indexer interface using a
 * list-based index structure.
 * 
 * A Hash Map based implementation of Indexing
 * 
 */
public class Indexer implements IndexerInterface, Serializable {
	/**
	 * The constructor for ListWebIndex.
	 */

	// Index Structure
	DictionaryInterface<String, Object> index;

	// This is for calculating the term frequency
	HashMap<?, ?> wordFrequency;

	public Indexer(String mode) {
		// hash - Dictionary Structure based on a Hashtable or HashMap from the Java
		// collections
		// list - Dictionary Structure based on Linked List
		// myhash - Dictionary Structure based on a Hashtable implemented by the
		// students
		// bst - Dictionary Structure based on a Binary Search Tree implemented by the
		// students
		// avl - Dictionary Structure based on AVL Tree implemented by the students

		if (mode.equals("hash"))
			index = new HashDictionary();
		else if (mode.equals("list"))
			index = new ListDictionary();
		else if (mode.equals("myhash"))
			index = new MyHashDictionary();
		else if (mode.equals("bst"))
			index = new BSTDictionary();
		else if (mode.equals("avl"))
			index = new AVLDictionary();
	}

	/**
	 * Add the given web page to the index.
	 *
	 * @param url      The web page to add to the index
	 * @param keywords The keywords that are in the web page
	 * @param links    The hyperlinks that are in the web page
	 */
	public void addPage(URL url, ObjectIterator<?> keywords) {

		Map<Object, Integer> map1 = new HashMap<>();
//System.out.println("add page method???????");
		////////////////////////////////////////////////////////////////////
		// Write your Code here as part of Integrating and Running Mini Google
		//////////////////////////////////////////////////////////////////// assignment
		//
		///////////////////////////////////////////////////////////////////

		// Map<Object,Object> map1 = new HashMap<>();
		// System.out.println(url.toString() + "" +
		// "----------------------------------------------------------");
		int count = 0;
		while (keywords.hasNext()) {
			String v = keywords.next().toString();
			if (map1.containsKey(v)) {
				count = map1.get(v);

				map1.put(v, ++count);

			} else {
				map1.put(v, 1);
			}
			// index.insert(keywords.next().toString(), url.toString());

		}

		for (Entry<Object, Integer> keyset : map1.entrySet()) {

			// index.insert((String) keyset.getKey(), keyset.getValue() + "-" + url);
			String key = String.valueOf(keyset.getKey());
			// String value = String.valueOf(keyset.getValue());
			// System.out.println("INserted-----------");
			index.insert(key, keyset.getValue() + "-->" + url);

		}
		System.out.println("call");
		// ObjectIterator<?> obj =retrievePages();
		// System.out.println("hiii");
		// System.out.println(obj.toString());

	}

	/**
	 * Produce a printable representation of the index.
	 *
	 * @return a String representation of the index structure
	 */
	public String toString() {
		////////////////////////////////////////////////////////////////////
		// Write your Code here as part of Integrating and Running Mini Google
		//////////////////////////////////////////////////////////////////// assignment
		//
		///////////////////////////////////////////////////////////////////
		return "You dont need to implement it\n";
	}

	/**
	 * Retrieve all of the web pages that contain the given keyword.
	 *
	 * @param keyword The keyword to search on
	 * @return An iterator of the web pages that match.
	 */
	public ObjectIterator<?> retrievePages(PageWord keyword) {

		////////////////////////////////////////////////////////////////////
		// Write your Code here as part of Integrating and Running Mini Google
		//////////////////////////////////////////////////////////////////// assignment
		//
		///////////////////////////////////////////////////////////////////
		System.out.println("Retrieve pages method------------");
		// System.out.println(keyword.toString());

		return new ObjectIterator<PageElementInterface>(new Vector<PageElementInterface>());
	}

	/**
	 * Retrieve all of the web pages that contain any of the given keywords.
	 * 
	 * @param keywords The keywords to search on
	 * @return An iterator of the web pages that match.
	 * 
	 *         Calculating the Intersection of the pages here itself
	 **/
	public ObjectIterator<?> retrievePages(ObjectIterator<?> keywords) {
		////////////////////////////////////////////////////////////////////
		// Write your Code here as part of Integrating and Running Mini Google
		//////////////////////////////////////////////////////////////////// assignment
		//
		///////////////////////////////////////////////////////////////////
		System.out.println("heyy retrieve pages");
		Vector<String> v2 = new Vector<>();

		String[] s = index.getKeys();
		while (keywords.hasNext()) {
			String keyyword = String.valueOf(keywords.next());
			for (int i = 0; i < s.length; i++) {
				// System.out.println("s[i] is :" + s[i]);
				// System.out.println("keyword is :" + keyyword);

				if (s[i].equals(keyyword)) {
					// System.out.println("matched");
					String value = String.valueOf(index.getValue(s[i]));
					v2.add(value);
				}
			}
		}

		// System.out.println("out of forloop");
		ObjectIterator<String> obj1 = new ObjectIterator<>(v2);

		// return new ObjectIterator<PageElementInterface>(new
		// Vector<PageElementInterface>());
		return obj1;
	}

	/**
	 * Save the index to a file.
	 *
	 * @param stream The stream to write the index
	 */
	public void save(FileOutputStream stream) throws IOException {

		////////////////////////////////////////////////////////////////////
		// Write your Code here as part of Integrating and Running Mini Google
		//////////////////////////////////////////////////////////////////// assignment
		//
		///////////////////////////////////////////////////////////////////

		// stream = new FileOutputStream("project.txt");
		ObjectOutputStream obj = new ObjectOutputStream(stream);
		obj.writeObject(index);

	}

	/**
	 * Restore the index from a file.
	 *
	 * @param stream The stream to read the index
	 */
	public void restore(FileInputStream stream) throws IOException {

		////////////////////////////////////////////////////////////////////
		// Write your Code here as part of Integrating and Running Mini Google
		//////////////////////////////////////////////////////////////////// assignment
		//
		///////////////////////////////////////////////////////////////////
		ObjectInputStream ois = new ObjectInputStream(stream);
		try {
			// Map<Object,Integer> map2 = new HashMap<>();
			System.out.println("index");
			index = (DictionaryInterface<String, Object>) ois.readObject();

			// System.out.println(ois.toString());

		} catch (ClassNotFoundException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
	}

	/*
	 * Remove Page method not implemented right now
	 * 
	 * @see searchengine.indexer#removePage(java.net.URL)
	 */
	public void removePage(URL url) {

	}
}
