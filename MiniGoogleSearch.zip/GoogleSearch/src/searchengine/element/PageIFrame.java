package searchengine.element;

public class PageIFrame implements PageElementInterface {

	public PageIFrame (String h) /* perhaps throw an invalid filename error? */{
		IFRAME = h;
	}

	public String toString () {
		return IFRAME;
	}

	private String IFRAME;

}
