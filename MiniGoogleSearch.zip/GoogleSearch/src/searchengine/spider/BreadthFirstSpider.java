/**  
 * 
 * Copyright: Copyright (c) 2004 Carnegie Mellon University
 * 
 * This program is part of an implementation for the PARKR project which is 
 * about developing a search engine using efficient Datastructures.
 * 
 * Modified by Mahender on 12-10-2009
 */
package searchengine.spider;

import java.net.URL;
import java.util.Iterator;
import java.util.LinkedList;
import java.util.Queue;
import java.util.Vector;

import searchengine.dictionary.ObjectIterator;
import searchengine.element.PageElementInterface;
import searchengine.element.PageFrame;
import searchengine.element.PageHref;
import searchengine.element.PageIFrame;
import searchengine.element.PageImg;
import searchengine.element.PageNum;
import searchengine.element.PageWord;
import searchengine.indexer.Indexer;
import searchengine.parser.PageLexer;
import searchengine.url.URLTextReader;

/**
 * Web-crawling objects. Instances of this class will crawl a given web site in
 * breadth-first order.
 */
public class BreadthFirstSpider implements SpiderInterface {

	/**
	 * Create a new web spider.
	 * 
	 * @param u The URL of the web site to crawl.
	 * @param i The initial web index object to extend.
	 */

	private Indexer i = null;
	private URL u;

	public BreadthFirstSpider(URL u, Indexer i) {
		this.u = u;
		this.i = i;

	}

	/**
	 * Crawl the web, up to a certain number of web pages.
	 * 
	 * @param limit The maximum number of pages to crawl.
	 */
	public Indexer crawl(int limit) {

		////////////////////////////////////////////////////////////////////
		// Write your Code here as part of Breadth First Spider assignment
		//
		///////////////////////////////////////////////////////////////////

		// URLTextReader in = new URLTextReader(u);
		PageLexer<PageElementInterface> elts;
		// Vector<Object> vector = new Vector<>();
		ObjectIterator<?> keywords = null;
		Queue<Object> q = new LinkedList<Object>();
		Queue<Object> q1 = new LinkedList<>();
		int limitReached = 0;
		/*
		 * while(limiteached<limit) {
		 * 
		 * }
		 */
		// System.out.println("url is" + u.toString());
		q.add(u.toString());
		q1.add(u.toString());
		while (limitReached < 3) {
			Vector<Object> vector = new Vector<>();
			// System.out.println(u);

			try {
				if (!q.isEmpty()) {
//					System.out.println("before" + q.toString());

					u = new URL(q.remove().toString());
//					System.out.println("after" + q.toString());
					URLTextReader in = new URLTextReader(u);
					System.out.println("url processeing" + u.toString());
					elts = new PageLexer<PageElementInterface>(in, u);
					int count = 0;

					while (elts.hasNext()) {
						count++;
						PageElementInterface elt = (PageElementInterface) elts.next();
						if (elt instanceof PageWord) {
							// System.out.println("word: " + elt);

							vector.add(elt);

						}

						else if (elt instanceof PageHref) {
							// System.out.println("link: " + elt);
							/*
							 * if(!(q.contains(elt))) { q.add(elt);
							 * 
							 * }
							 */
//							System.out.println(q1.contains("https://www.javatpoint.com"));
							String val = elt.toString();
							if(val.charAt(val.length()-1) != '/') {
								val = val+"/";
							}
							if (!(q1.contains(val))) {
								q.add(val);
								q1.add(val);
								//System.out.println(q.toString());

							}

						} else if (elt instanceof PageNum) {
							// System.out.println("num: " + elt);

						} else if (elt instanceof PageImg) {
							// System.out.println("img: " + elt);

						} else if (elt instanceof PageFrame) {
							// System.out.println("img: " + elt);

						} else if (elt instanceof PageIFrame) {
							// System.out.println("img: " + elt);

						}
						// System.out.println("INNER LOOOP WHILE++++++++");
					}
					// System.out.println("OUT OF LOOOP WHILE++++++++");

					keywords = new ObjectIterator<>(vector);
					i.addPage(u, keywords);
					
					/*
					 * Iterator<Object> it = q1.iterator(); while (it.hasNext()) { if
					 * ((!u.equals(it.next()))) { q.add(it.next()); } }
					 */
					// String s = (String) q.remove();
					// System.out.println(s+"removed");

				} else {
					break;
				}

			} catch (Exception e) {
				// TODO: handle exception
				e.printStackTrace();
			}

			limitReached++;
			System.out.println("LIMIT IS --------------" + limitReached);

		}
		System.out.println("Finish");
		return i;
	}

	/**
	 * Crawl the web, up to the default number of web pages.
	 */
	public Indexer crawl() {
		// This redirection may effect performance, but its OK !!
		System.out.println("Crawling: " + u.toString());

		return crawl(crawlLimitDefault);
	}

	/** The maximum number of pages to crawl. */
	public int crawlLimitDefault = 10;

}
