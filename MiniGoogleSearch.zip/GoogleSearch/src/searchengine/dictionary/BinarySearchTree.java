package searchengine.dictionary;

public class BinarySearchTree<K, V> {

	String keys = "";
	V value = null;

	class Node<K, V> {
		K key;
		V value;
		Node left, right;

		public Node(K key, V value) {
			this.key = key;
			this.value = value;
			left = right = null;
		}
	}

	public BinarySearchTree() {
		root = null;
	}

	Node root;

	public void insertNode(K key, V value) {
		root = createBst(root, key, value);
		// System.out.println(root.key);

	}

	// Construction of BST

	public Node createBst(Node root, K key, V value) {

		int k = Integer.parseInt((String) key);
		int v = Integer.parseInt((String) value);

		if (root == null) {

			root = new Node(key, value);
			return root;

		}
		int rootKey = Integer.valueOf((String) root.key);
		// int rootValue = (int) root.value;

		// if (root != null) {
		if (k < rootKey) {
			root.left = createBst(root.left, key, value);

		} else if (k > rootKey) {
			root.right = createBst(root.right, key, value);
		}
		// }

		return root;

	}

	/* End of construction of BST */

	// Method to retrieve keys from BST

	public String[] retrieveKeys() {
		keys = "";
		String keyys = inorder(root);
		String[] kkeys = keyys.split(",");
		System.out.println(keyys);
		return kkeys;
	}

	public String inorder(Node root) {
		if (root != null) {
			keys += root.key + ",";
			inorder(root.left);
			inorder(root.right);

		}
		return keys;
	}

	// Method to retrieve values from BST

	public V retrieveValues(K key) {

		return getValues(key, root);
	}

	public V getValues(K key, Node root) {
		if (root != null) {
			if (key.equals(root.key)) {

				value = (V) root.value;

			} else {

				getValues(key, root.left);
				getValues(key, root.right);

			}
		}
		return value;
	}

	// Method to delete the node from BST

	public void deleteNode(K key) {

		if (root != null) {

			// Logic to delete the root node in BST

			if (key.equals(root.key)) {

				if (root.left != null && root.right != null) {
					Node root1 = root.right;
					Node prev = null;
					if (root1.left == null) {
						root1.left = root.left;
						root = root1;

					} else {
						while (root1.left != null) {
							prev = root1;
							root1 = root1.left;

						}

						if (root1.right != null) {
							prev.left = root1.right;
						} else {
							prev.left = null;

							root1.right = prev;

						}

						root1.left = root.left;

						root = root1;
						System.out.println(root.key + " " + root1.key);
					}
				} else {
					root = null;
					return;
				}

			}

			// Logic to delete selected Node

			else {

				Node searchedRoot = search(root, key);
				int key1 = Integer.valueOf((String) key);
				System.out.println("searched key" + searchedRoot.key);
				Node temp1;
				if (key1 > Integer.valueOf((String) searchedRoot.key)) {
					temp1 = searchedRoot.right;
				} else {
					temp1 = searchedRoot.left;
				}

				if (temp1.right == null) {
					temp1 = temp1.left;
				} else {
					Node root1 = temp1.right;
					Node prev = null;
					if (root1.left == null) {
						root1.left = temp1.left;
						temp1 = root1;

					} else {
						while (root1.left != null) {
							prev = root1;
							root1 = root1.left;

						}

						if (root1.right != null) {
							prev.left = root1.right;
						} else {
							prev.left = null;

							root1.right = prev;

						}

						root1.left = temp1.left;

						temp1 = root1;
						System.out.println(temp1.key + " " + root1.key);
					}
				}
				if (key1 > Integer.valueOf((String) searchedRoot.key)) {
					searchedRoot.right = temp1;
				} else {
					searchedRoot.left = temp1;
				}

				/*
				 * if (searchedRoot.right != null) { //Node temp1 = searchedRoot.right; if
				 * (temp1.right != null) {
				 * 
				 * Node temp2 = temp1.right; ` if (temp2.right != null) { while (temp2.left !=
				 * null) { temp2 = temp2.left;
				 * 
				 * } } else { searchedRoot.right = temp2.right; temp2.left = temp1.right; }
				 * 
				 * searchedRoot.right = temp2; System.out.println(searchedRoot.right.key); }
				 * 
				 * }
				 */
			}

		}
	}

	Node temp = null;

	public Node search(Node root, K key) {

		int rootKey = Integer.valueOf((String) root.key);
		int userKey = Integer.valueOf((String) key);
		if (root != null) {

			Node prev = root;
			System.out.println("prev root" + root.key);
			if (root.left != null) {
				if (key.equals(root.left.key)) {
					System.out.println("matched root" + root.key);
					temp = root;
					// System.out.println("temp is"+prev.key);
					return temp;
				}
			}
			if (root.right != null) {
				if (key.equals(root.right.key)) {
					/*Node rightmostroot = root;
					if (rightmostroot.right != null) {
						// prev.right=null;
					}*/ 
					temp = root;
					return temp;

				}
			}

			if (userKey < rootKey) {
				search(root.left, key);
			} else if (userKey > rootKey) {
				search(root.right, key);
			}
			// search(root.right, key);
			System.out.println("root is" + root.key);

		}

		return temp;

	}

}