package searchengine.dictionary;

import java.io.Serializable;

//Node class to store key,value and node

class Node<K, V> implements Serializable {

	K key;
	V value;
	Node next;

	public Node(K key, V value) {
		this.key = key;
		this.value = value;
		next = null;
	}

}

//Userdefined linked list with key value pairs

public class UserdefinedLinkedList<K, V> implements Serializable {

	Node head;
	Node node;

	// Creating linkedlist with key and values

	public void createLinkedList(K key, V value) {

		node = new Node(key, value);

		if (head == null) {
			head = node;
		} else {
			Node n = head;
			if (key.equals(n.key)) {
				n.value = value;
				return;
			}
			while (n.next != null) {

				n = n.next;
				if (key.equals(n.key)) {
					n.value = value;
					return;
				}
			}
			if (key != n.key || head.key != key) {
				n.next = node;
			}

		}

	}

	// Remove key value pair based on the key given

	public void delete(K key) {

		Node n1 = head;
		if (head.key.equals(key)) {
			head = head.next;
		} else {
			n1 = n1.next;
			Node prev = head;
			while (n1 != null) {

				if (n1.key.equals(key)) {
					prev.next = n1.next;
//					if (n1.next != null) {
//						head.next = n1.next;
//					}
//					/*else if (n1.key.equals(key) && n1.next == null) {
//
//						n1.next = null;
//					}*/
//					
//					else {
//						
//						n1.next=null;
//					}
				}
				prev = n1;
				n1 = n1.next;
			}
		}
	}

	public String[] retrieveKeys() {
		Node n2 = head;
		String keys = "";
		keys += head.key;
		while (n2.next != null) {
			n2 = n2.next;
			keys += "," + n2.key;
		}
		System.out.println(keys);
		String[] keys1 = keys.split(",");
		return keys1;

	}

	public V retrieveValues(K str) {

		Node n4 = head;
		V value3 = null;
		if (n4.key.equals(str)) {
			value3 = (V) head.value;
		} else {
			while (n4.next != null) {
				n4 = n4.next;
				if (n4.key.equals(str)) {

					value3 = (V) n4.value;
				}
			}
		}
		return value3;

	}

	public void display() {

		node = head;
		System.out.println("key :" + node.key + " " + "value is :" + node.value);
		while (node.next != null) {
			node = node.next;
			System.out.println("key :" + node.key + " " + "value is :" + node.value);
		}

	}

}
