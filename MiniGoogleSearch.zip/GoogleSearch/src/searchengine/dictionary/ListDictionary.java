package searchengine.dictionary;

import java.io.Serializable;

public class ListDictionary<K extends Comparable<K>, V> implements DictionaryInterface<K, V>,Serializable {

	UserdefinedLinkedList userdefinedlinkedlist = new UserdefinedLinkedList<K, V>();

	@Override
	public K[] getKeys() {
		// TODO Auto-generated method stub

		String[] keys2 = userdefinedlinkedlist.retrieveKeys();
		return (K[]) keys2;
	}

	@Override
	public V getValue(K str) {
		// TODO Auto-generated method stub

		V valuess = (V) userdefinedlinkedlist.retrieveValues(str);

		return valuess;
	}

	@Override
	public void insert(K key, V value) {
		// TODO Auto-generated method stub
		// System.out.println("Entered list method");
		userdefinedlinkedlist.createLinkedList(key, value);
		userdefinedlinkedlist.display();
	}

	@Override
	public void remove(K key) {
		// TODO Auto-generated method stub
		userdefinedlinkedlist.delete(key);
		System.out.println("after deletion");
		userdefinedlinkedlist.display();

	}

}
