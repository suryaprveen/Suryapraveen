package searchengine.dictionary;

import java.io.Serializable;
import java.util.HashMap;
import java.util.Iterator;
import java.util.Map;
import java.util.Map.Entry;

public class HashDictionary<K extends Comparable<K>, V> implements DictionaryInterface<K, V>,Serializable{

	Map<K, V> map = new HashMap<>();

	@Override
	public K[] getKeys() {
		// TODO Auto-generated method stub
		String keysss = "";

		for (Entry<K, V> map : map.entrySet()) {
			K key3 = map.getKey();
			keysss += "" + key3 + ",";
		}
		K[] keys7 = (K[]) keysss.split(",");
		return keys7;
	}

	@Override
	public V getValue(K str) {
		// TODO Auto-generated method stub

		V val = map.get(str);

		return val;
	}

	int count = 0;

	@Override
	public void insert(K key, V value) {
		// TODO Auto-generated method stub
		//System.out.println("hash dictionary");
		if(map.isEmpty()) {
			map.put(key, value);

		}
		 else {
			if (map.containsKey(key)) {
				//count++;

				map.put(key, (V) (map.get(key) + "--->" + value));
			} else {
				map.put(key, value);
			}
		}

		for (Entry<K, V> map : map.entrySet()) {
			System.out.println("Key :" + map.getKey() + "  " + "value :" + map.getValue());
			System.out.println("-------------");
		}
	}

	@Override
	public void remove(K key) {
		// TODO Auto-generated method stub
		map.remove(key);

	}

}
