package searchengine.dictionary;

public class BSTDictionary<K extends Comparable<K>, V> implements DictionaryInterface<K, V> {

	BinarySearchTree<K, V> binarysearchtree = new BinarySearchTree<>();

	@Override
	public K[] getKeys() {
		// TODO Auto-generated method stub

		K[] keeys = (K[]) binarysearchtree.retrieveKeys();

		return keeys;
	}

	@Override
	public V getValue(K str) {
		// TODO Auto-generated method stub

		V value = binarysearchtree.retrieveValues(str);

		return value;
	}

	@Override
	public void insert(K key, V value) {
		// TODO Auto-generated method stub

		binarysearchtree.insertNode(key, value);
	}

	@Override
	public void remove(K key) {
		// TODO Auto-generated method stub
		
		binarysearchtree.deleteNode(key);
		

	}

}
