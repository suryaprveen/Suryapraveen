package searchengine.dictionary;

public class MyHashDictionary<K extends Comparable<K>, V> implements DictionaryInterface<K, V> {
	int size = 10;
	UserdefinedHashTable userdefhashtable = new UserdefinedHashTable<K, V>(size);

	@Override
	public K[] getKeys() {
		// TODO Auto-generated method stub
		String keey = "";
		String[] kkey = null;
		for (int i = 0; i < size; i++) {
			if (userdefhashtable.ll[i] != null) {
				Node n = userdefhashtable.ll[i].head;
				keey += "" + n.key;
				while (n.next != null) {
					n = n.next;
					keey += "," + n.key;
				}
			}

		}

		if (!(keey.isEmpty())) {
			kkey = keey.split(",");

		}

		return (K[]) kkey;
	}

	@Override
	public V getValue(K str) {
		// TODO Auto-generated method stub

		int possition = Integer.parseInt((String) str);
		int pos2 = possition % size;
		V value = (V) userdefhashtable.ll[pos2].retrieveValues(str);

		return value;
	}

	@Override
	public void insert(K key, V value) {
		// TODO Auto-generated method stub

		userdefhashtable.add(key, value);

	}

	@Override
	public void remove(K key) {
		// TODO Auto-generated method stub
		userdefhashtable.delete(key);

	}

}
