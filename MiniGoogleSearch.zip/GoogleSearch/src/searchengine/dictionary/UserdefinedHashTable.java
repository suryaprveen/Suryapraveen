package searchengine.dictionary;

public class UserdefinedHashTable<K, V> {
	UserdefinedLinkedList<K, V> ll[];
	int size;

	public UserdefinedHashTable(int size) {

		ll = new UserdefinedLinkedList[10];

		this.size = size;

	}

	public void add(K key, V value) {
		// int size=ll.length;

		int hashKey = Integer.parseInt((String) key);
		int position = ((hashKey) % size);
		if (ll[position] == null) {
			ll[position] = new UserdefinedLinkedList<>();

		}

		ll[position].createLinkedList(key, value);

	}

	public void delete(K key) {

		System.out.println("Entered delete method");
		int pos1 = Integer.parseInt((String) key);
		int pos = pos1 % size;
		if (ll[pos] != null) {
			Node head = ll[pos].head;
			Node temp = ll[pos].head;
			System.out.println("head key" + head.key);

			if (head != null) {
				if (head.key.equals(key)) {
					if (head.next == null) {
						System.out.println("***");
						ll[pos].head = null;
					} else {
						ll[pos].head = ll[pos].head.next;
						System.out.println("--" + head.key);
						return;
					}
				} else {
					Node n = ll[pos].head;

					n = n.next;
					Node prev = ll[pos].head;

					while (n != null) {
						if (key.equals(n.key)) {
							prev.next = n.next;
							break;
						}

						prev = n;

						n = n.next;

					}
				}

			}

		} else {
			System.out.println("Can't perform delete operation as there are no elements in hashtable");
		}

		// Node prev = n;
	}

}
