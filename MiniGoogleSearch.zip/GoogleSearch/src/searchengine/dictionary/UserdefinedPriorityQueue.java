package searchengine.dictionary;

class Node1 {
	int priority;
	String value;
	Node1 next;

	public Node1(int priority, String value) {
		this.priority = priority;
		this.value = value;
		next = null;

	}

}

/*
 * class PriorityQueue {
 * 
 * Node1 head;
 * 
 * public void insert(int priority,String value) { Node1 node = new
 * Node1(priority,value);
 * 
 * if (head == null) { head = node; } else { Node1 node1 = head; while
 * (node1.next != null) { node1 = node1.next; } if (head != null) { if (priority
 * < node1.priority) { node1.next = node;
 * 
 * }
 * 
 * else {
 * 
 * Node1 temp2 = head; if (priority > temp2.priority) { Node1 temp = head; head
 * = node; head.next = temp; } else { while (temp2.next != null) { Node1 prev =
 * temp2; temp2 = temp2.next; if (priority > temp2.priority) { for (int i = 0; i
 * < 1; i++) { prev.next = node; node.next = temp2; return; // temp2.next =
 * node3; } } } }
 * 
 * } } }
 * 
 * }
 * 
 * public void inorderDisplay() {
 * 
 * if (head != null) { System.out.println(head.priority+"  "+head.value);
 * 
 * while (head.next != null) { head = head.next;
 * System.out.println(head.priority+"  "+head.value); } }
 * 
 * }
 * 
 * }
 * 
 */
public class UserdefinedPriorityQueue {

	Node1 head;

	public void insert(int priority, String value) {
		Node1 node = new Node1(priority, value);

		if (head == null) {
			head = node;
		} else {
			Node1 node1 = head;
			while (node1.next != null) {
				node1 = node1.next;
			}
			if (head != null) {
				if (priority < node1.priority) {
					node1.next = node;

				}

				else {

					Node1 temp2 = head;
					if (priority > temp2.priority) {
						Node1 temp = head;
						head = node;
						head.next = temp;
					} else {
						while (temp2.next != null) {
							Node1 prev = temp2;
							temp2 = temp2.next;
							if (priority > temp2.priority) {
								for (int i = 0; i < 1; i++) {
									prev.next = node;
									node.next = temp2;
									return;
									// temp2.next = node3;
								}
							}
						}
					}

				}
			}
		}

	}

	public String deleteElement(int keyword) {

		String s ="";
		if (head != null) {
			if (keyword == head.priority) {

				head = head.next;

			} else {
				Node1 node3 = head;
				while (node3.next != null) {
					Node1 prev1 = node3;
					node3 = node3.next;
					if (keyword == node3.priority) {
						prev1.next = node3.next;
						s+=keyword+" "+node3.value;
					}

				}
			}
		}
		return s;
		

	}

}
