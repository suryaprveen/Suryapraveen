import traceback

import mpu;
import pymysql
# import mysql.connector

from collections import Counter

# Removing unwanted words from user entered query

query = str(input("Please enter your query :"))
stopwords = []
column_name=""
column_name1=""

# Reading unwanted words from file

with open("C:/Users/surya/PycharmProjects/StockMarket/Stopwords.txt", "r") as myfile:
    for i in myfile:
        replaced_word = i.replace('"', '')
        l1 = replaced_word.strip('\n')
        stopwords.append(l1)

# Splitting user entered query

querywords = query.split()

# Checking entered query with stop words and removing unwanted words from user enterd query

result = [word for word in querywords if word.lower() not in stopwords]

# Result words after removing unwanted words

result_words = result
#
# # ----------------------------------------------------------------------------------
# # Checking the result words with words in config file and getting table name
#
config_words = []
list_of_items = []
stats=[]
profiles = []
finances = []
# --------------------------------------------------------------------------------------
# Reading from the config file

with open("C:/Users/surya/PycharmProjects/StockMarket/config.txt")as file:
    for i in file:
        str = i.strip("\n")
        config_words = str.split(";")
        list_of_items.append(str)

# # Flattening list that is converting list of lists to normal single list
#
items_splitted=[i.split(':') for i in list_of_items]
flattened_items=mpu.datastructures.flatten(items_splitted)
# print(flattened_items)
# # -----------------------------------------------------------------------------
#
# # making seperate lists for statistics,profiles,financials
#
for i in range(0, 25):
    stats.append(flattened_items[i])
for j in range(26, 47):
    profiles.append(flattened_items[j])
for k in range(48, 61):
     finances.append(flattened_items[k])
# print(stats)
# print(profiles)
# print(finances)

# for res_words in result_words:
#   print(res_words)


# stop_words = ['cbcfb','income', 'google', 'whathfgh']
# list = ['profiles', 'profit', 'sdf', 'in', 'incomef', 'what,how']
result_words
flag = 0
table_name = ""
companyname=""
error = 0
column_count=0
# ---------------------------------------------------------------------

# Searching the entered query in finances list and returning table name to which it belongs

for i in range(0, len(result_words)):
    flag = 1


    for j in range(1, len(finances) - 1, 2):
        # print(result_words[i])
        # print(finances[j])
        str1=result_words[i]
        str2=finances[j]
        s2=str2.rstrip()

        if (str1 in s2):
            flag = 0

            for k in result_words:
                # print(k)
                # print(finances[j+1])


                present=finances[j+1].find(",")
                if(present!=-1):
                    seperated_values=finances[j+1].split(",")
                    # print(seperated_values)
                    for stp_wrds in result_words:
                        # print("stop"+stp_wrds)
                        for x in range(0,len(seperated_values)):
                            # print("comma vales"+x)
                            if(stp_wrds in seperated_values[x]):
                                table_name = finances[0]
                                column_count+=1
                                column_name=s2

                                # print(table_name)
                                break
                elif(present==-1):
                    column_count=0
                    for sttp in result_words:
                        if (sttp in finances[j + 1]):
                            table_name = finances[0]
                            column_count+=1
                            column_name = s2

                            break;
                break;

        if (flag == 0):
            break
# --------------------------------------------------------------------------------------------------
# Searching the entered in profiles list nd returning the table name to which it belongs

for i in range(0, len(result_words)):
    flag = 1


    for j in range(1, len(profiles) - 1, 2):
        # print(result_words[i])
        # print(profiles[j])
        str1=result_words[i]
        str2=profiles[j]
        s2=str2.rstrip()

        if (str1 in s2):
            flag = 0

            for k in result_words:
                # print(k)
                # print(profiles[j+1])


                present=profiles[j+1].find(",")
                if(present!=-1):
                    seperated_values=profiles[j+1].split(",")
                    # print(seperated_values)
                    for stp_wrds in result_words:
                        # print("stop"+stp_wrds)
                        for x in range(0,len(seperated_values)):
                            # print("comma vales"+x)
                            if(stp_wrds in seperated_values[x]):
                                column_count=0
                                column_count+=1
                                table_name = profiles[0]
                                if(column_count==1):
                                    column_name+=","+s2
                                else:
                                    column_name=s2
                                # print(table_name)
                                break
                elif(present==-1):
                    for sttp in result_words:
                        if (sttp in profiles[j + 1]):
                            column_count=0
                            column_count+=1
                            table_name = profiles[0]
                            if(column_count==1):
                                column_name +=","+s2
                            else:
                                column_name=s2
                            break;
                break;

        if (flag == 0):
            break
# --------------------------------------------------------------------------------------------
# Searching given query in statistics list and returning the table name to which it belongs

for i in range(0, len(result_words)):
    flag = 1


    for j in range(1, len(stats) - 1, 2):
        # print(result_words[i])
        # print(stats[j])
        str1=result_words[i]
        str2=stats[j]
        s2=str2.rstrip()

        if (str1 in s2):
            flag = 0

            for k in result_words:
                # print(k)
                # print(stats[j+1])


                present=stats[j+1].find(",")
                if(present!=-1):
                    seperated_values=stats[j+1].split(",")
                    # print(seperated_values)
                    for stp_wrds in result_words:
                        # print("stop"+stp_wrds)
                        for x in range(0,len(seperated_values)):
                            # print("comma vales"+x)
                            if(stp_wrds in seperated_values[x]):
                                column_count=0
                                column_count+=1
                                table_name = stats[0]
                                if(column_count==1):
                                    column_name+=","+s2
                                else:
                                    column_name=s2
                                # print(table_name)
                                break
                elif(present==-1):
                    for sttp in result_words:
                        if (sttp in stats[j + 1]):
                            column_count=0
                            column_count+=1
                            table_name = stats[0]
                            if(column_count==1):
                                column_name +=","+s2
                            else:
                                column_name=s2
                            break;
                break;

        if (flag == 0):
            break


if (table_name == ""):
    print("Please enter correct query")
else:
    # table_name1=table_name
    column_name1=column_name.upper()
    # print(table_name)
    # print(column_name1)

# ------------------------------------------------------------

# Fetching company names
ticker_list=[]
limit=0
with open("C:/Users/surya/PycharmProjects/StockMarket/ticker.txt","r") as myfile1:
    for tickers in myfile1:
        limit+=1
        list_tickers1=tickers.split(':')
        ticker_list.append(list_tickers1[0])

        if(limit==6):
            break
ticckers=[]
for i in ticker_list:
    ticckers.append(i.rstrip())
# print("***")
# print(ticckers)

for compny_names in result_words:
    print(compny_names)
    for i in range(0,len(ticckers)):
        # print(ticckers[i])
        if(compny_names in ticckers[i]):
            # print(";;;;;")
            companyname=ticckers[i]

            break;

# print(companyname)
compaany_name="'"+companyname+"'"
column_name2=column_name1.lstrip(",")

# ----------------------------------------------------------------

# Generation of dynamic query
if(companyname.__eq__("")):
    query="select"+" "+column_name2+" "+"from"+" "+table_name+" "+";"
else:
    query="select"+" "+column_name2+" "+"from"+" "+table_name+" "+"where"+" "+column_name2+" "+"="+" "+compaany_name+";"
print(query)


# ---------------------------------------------------------------

# Connecting to db and fetching data with the generated dynamic query

try:
    mydb = pymysql.connect(
    host="localhost",
    user="root",
    passwd="root",
    database="stockmarket")


    mycursor = mydb.cursor()

    connectings=mycursor.execute(query)
    print(connectings)

    myresult = mycursor.fetchall()


    # print(myresult)
    for x in myresult:
        print(x,end='')
except Exception as e:
      print("Unknown column in the field list")

