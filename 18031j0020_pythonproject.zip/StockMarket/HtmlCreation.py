import os
import requests
from bs4 import BeautifulSoup
count=0

with open("C:/Users/surya/PycharmProjects/StockMarket/ticker.txt","r") as myfile:
    for i in myfile:
        count+=1
        print(count)
        l=i.split(":")

        # Urls
        profileUrl = 'https://finance.yahoo.com/quote/' + l[0] + '/profile?p=' + l[0]
        SummaryUrl = 'https://finance.yahoo.com/quote/'+l[0]+'?p='+l[0]
        StatisticsUrl='https://finance.yahoo.com/quote/'+l[0]+'/key-statistics?p='+ l[0]
        FinancialsUrl='https://finance.yahoo.com/quote/' + l[0] + '/financials?p=' + l[0]

        # Files
        profile_file = open("C:/Users/surya/PycharmProjects/StockMarket/"+l[0]+"/profile.html", "w")
        summary_file= open("C:/Users/surya/PycharmProjects/StockMarket/"+l[0]+"/summary.html", "w")
        statistics_file=open("C:/Users/surya/PycharmProjects/StockMarket/"+l[0]+"/statistics.html", "w")
        Financials_file=open("C:/Users/surya/PycharmProjects/StockMarket/"+l[0]+"/financials.html", "w")

        # Sending requests to respective url's

        profile_page = requests.get(profileUrl)
        summary_page=requests.get(SummaryUrl)
        statistics_page=requests.get(StatisticsUrl)
        financials_page=requests.get(FinancialsUrl)

        # Writing to the respective folders

        if (profile_page.status_code == 200):
            soup = BeautifulSoup(profile_page.text, 'html.parser')
            profile_file.write(str(soup.encode("utf-8")))
            print("profile page successfully written")
        if(summary_page.status_code==200):
            soup = BeautifulSoup(summary_page.text, 'html.parser')
            summary_file.write(str(soup.encode("utf-8")))
            print("summary page successfully written")
        if (statistics_page.status_code == 200):
            soup = BeautifulSoup(statistics_page.text, 'html.parser')
            statistics_file.write(str(soup.encode("utf-8")))
            print("statistics page successfully written")
        if (financials_page.status_code == 200):
            soup = BeautifulSoup(financials_page.text, 'html.parser')
            Financials_file.write(str(soup.encode("utf-8")))
            print("financials page successfully written")
        if (count == 6):
            break






