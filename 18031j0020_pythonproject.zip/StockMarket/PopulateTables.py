import requests
from bs4 import BeautifulSoup
import urllib.request
import pymysql
import re


count = 0
str_emp = ""
db = pymysql.connect("localhost", "root", "root", "stockmarket")
cursor = db.cursor()
with open("C:/Users/surya/PycharmProjects/StockMarket/ticker.txt", "r") as myfile:
    for i in myfile:
        count += 1
        str_emp = ""
        rt=""
        income_str=""

        l = i.split(":")
        ticker = l[0]

        # urls

        url = "file:///C:/Users/surya/PycharmProjects/StockMarket/" + l[0] + "/profile.html"

        url_statistics = "file:///C:/Users/surya/PycharmProjects/StockMarket/" + l[0] + "/statistics.html"

        url_finance = "file:///C:/Users/surya/PycharmProjects/StockMarket/"+l[0]+"/financials.html"
#----------------------------------------------------------------------------------------------------
        # SENDING REQUESTS

        # Request for profile
        page = urllib.request.urlopen(url)
        page_stats=urllib.request.urlopen(url_statistics)
        page_finances=urllib.request.urlopen(url_finance)
#------------------------------------------------------------------------------------------
        # FETCHING SOUP OBJECT

        soup = BeautifulSoup(page.read(), "html.parser")
        soup_stats=BeautifulSoup(page_stats.read(),"html.parser")
        soup_financials=BeautifulSoup( page_finances.read(),"html.parser")
#-------------------------------------------------------------------------------------------------------
        # ATTRIBUTES FOR PROFILES TABLE

        # fetching class of name
        names = BeautifulSoup(str(soup.find_all(class_="Fz(m) Mb(10px)")), 'html.parser')
        name1 = names.get_text().strip("[]")

        # fetching class of address
        addresses = BeautifulSoup(str(soup.find_all(class_="D(ib) W(47.727%) Pend(40px)")), 'html.parser')
        addresses1 = addresses.get_text().strip("[]")
        urlless_address = re.sub(r'http\S+', '', addresses1)


        # fetching phonenumbers

        phonenumbers = BeautifulSoup(str(soup.find_all(class_="D(ib) W(47.727%) Pend(40px)")), 'html.parser')
        numbers = phonenumbers.find('a')
        numbers1 = numbers.text

        # fetching emails

        emails = BeautifulSoup(str(soup.find_all(class_="D(ib) W(47.727%) Pend(40px)")), 'html.parser')
        emailid = emails.get_text().strip("[]")
        emailids = re.findall('https?://(?:[-\w.]|(?:%[\da-fA-F]{2}))+', emailid)
        email = str(emailids).strip("[],''")


        sectors = BeautifulSoup(str(soup.find_all(class_="Fw(600)")), 'html.parser')
        sector1 = sectors.get_text().strip("[]")
        sectr = (sector1.split(","))
        sectorrs = sectr[0]
        industries = sectr[1]



        # fulltime employees

        ft_emp = BeautifulSoup(str(soup.find_all(class_="Fw(600)")), 'html.parser')
        emp = ft_emp.get_text().strip("[]")
        emp1 = re.findall('[0-9]', emp)
        for z in emp1:
            str_emp += z
#--------------------------------------------------------------------------------------------------
            # 2. Attributes for Finance Table

            # getting tottal revenue from html page
            tr = BeautifulSoup(str(soup_financials.find_all(class_="Fz(s) Ta(end) Pstart(10px)")), 'html.parser')
            revenue = tr.get_text().strip("[]")

            r = list(revenue)

            for q in r:
                rt += q

            rtr = rt.split(" ")
            total_revenue = rtr[3].strip(",")


            # getting cost revenue from html page
            cost_revenue = rtr[7].strip(",")

            # getting INCOME_BEFORE_TAXfrom html page
            income_before = rtr[35].strip(",")


            # getting NET_INCOME html page
            tr1 = BeautifulSoup(str(soup_financials.find_all(class_="Fw(600) Ta(end) Py(8px) Pt(36px)")), 'html.parser')
            income = tr1.get_text().strip("[]")
            income_list = list(income)
            for il in income_list:
                income_str += il


            income_final = income_str.split(" ")
            total_income_revenue = income_final[len(income_final) - 1].strip(",")

#----------------------------------------------------------------------------------
        #  ATTRIBUTES FOR Statistics TABLE

        market_capacity=BeautifulSoup(str(soup_stats.find_all(class_="Fz(s) Fw(500) Ta(end)")), 'html.parser')
        marketcap=market_capacity.get_text().strip("[]")
        # print(marketcap)
        market_capacity_list=marketcap.split(",")
        mark_capacity=market_capacity_list[0]
        enterprise_value=market_capacity_list[1]
        return_assets=market_capacity_list[15]
        total_cash=market_capacity_list[25]
        operating_cash = market_capacity_list[31]
        if(ticker=='ROKU'):
            operating_cash=market_capacity_list[32]
        levered_free_cash=market_capacity_list[32]
        if (ticker == 'ROKU'):
            levered_free_cash = market_capacity_list[33]
        total_deb=market_capacity_list[27]
        currnt_ratio=market_capacity_list[29]
        grss_profit=market_capacity_list[20]
        if(ticker=='ROKU'):
            grss_profit=market_capacity_list[21]
        prfit_margin=market_capacity_list[13]
        if(ticker=='ROKU'):
            prfit_margin=market_capacity_list[14]
        print(ticker+":"+prfit_margin)







# -------------------------------------------------------------
        # INSERTING INTO DATABASE

        # Inserting into profiles

        sql = "INSERT INTO Profiles (PROF_TICKER,NAME,ADDRESS,PHONENUM,WEBSITE,SECTOR,INDUSTRY,FULL_TIME) VALUES (%s,%s,%s,%s,%s,%s,%s,%s)"
        val = (ticker, name1, urlless_address, numbers1, email, sectorrs, industries, str_emp)
        cursor.execute(sql, val)

#--------------------------------------------------------------------

        # Inserting into financials table

        sql = "INSERT INTO Finances (FIN_TICKER,TOTAL_REVENUE,COST_OF_REVENUE,INCOME_BEFORE_TAX,NET_INCOME) VALUES (%s,%s,%s,%s,%s)"
        val = (ticker, total_revenue, cost_revenue, income_before, total_income_revenue)
        cursor.execute(sql, val)
#----------------------------------------------------------------------------------
        # Inserting into statistics table

        sql1 = "INSERT INTO Statistics (SNO,STAT_TICKER,MARKETCAP,ENTERPRISE_VALUE,RETURN_ON_ASSESTS,TOTAL_CASH,OPERATING_CASH_FLOW,LEVERED_FREE_CASH_FLOW,TOTAL_DEBT,CURRENT_RATIO,GROSS_PROFIT,PROFIT_MARGIN) VALUES (%s,%s,%s,%s,%s,%s,%s,%s,%s,%s,%s,%s)"
        val1 = (count,ticker,mark_capacity,enterprise_value,return_assets,total_cash,operating_cash,levered_free_cash,total_deb,currnt_ratio,grss_profit,prfit_margin)

        cursor.execute(sql1, val1)

        print(cursor.rowcount, "record inserted.")

        if (count == 6):
            break
db.commit()
