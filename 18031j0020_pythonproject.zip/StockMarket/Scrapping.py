import requests
from bs4 import BeautifulSoup
page=requests.get('https://finance.yahoo.com/trending-tickers')
soup=BeautifulSoup(page.text,'html.parser')
f=open('ticker.txt','w')

soup1=BeautifulSoup(str(soup.find_all(class_="yfinlist-table W(100%) BdB Bdc($tableBorderGray)")),'html.parser')
soup3=BeautifulSoup(str(soup1.find_all(class_="data-col0 Ta(start) Pstart(6px) Pend(15px)")),'html.parser')
ticker=soup3.find_all('a');
soup2=BeautifulSoup(str(soup1.find_all(class_="data-col1 Ta(start) Pstart(10px) Miw(180px)")),'html.parser')
name=soup2.find_all();
for i,j in zip(ticker,name):
    print(i.get_text())
    print(j.get_text())
    z=i.get_text()+":"+j.get_text()+"\n"
    f.write(z)