import os

count = 0
with open("C:/Users/surya/PycharmProjects/StockMarket/ticker.txt", "r") as myfile:
    for i in myfile:
        l = i.split(":")

        if os.path.exists(l[0]):
            print("Directory already exists")
        else:
            os.makedirs(l[0])
            print("Directory created")
        count += 1

        if (count == 6):
            break;
