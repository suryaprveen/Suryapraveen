import pymysql
db = pymysql.connect("localhost","root","root","stockmarket" )
mycursor = db.cursor()
try:
    mycursor.execute("DROP TABLE Statistics")
except Exception as e:
    pass
try:
    mycursor.execute("CREATE TABLE Statistics ( SNO INT(200),"
                     "STAT_TICKER VARCHAR(200),"
                     "MARKETCAP VARCHAR(200),"
                     "ENTERPRISE_VALUE VARCHAR(200),"
                     "RETURN_ON_ASSESTS VARCHAR(200),"
                     "TOTAL_CASH VARCHAR(200),"
                     "OPERATING_CASH_FLOW VARCHAR(200),"
                     "LEVERED_FREE_CASH_FLOW VARCHAR(200),"
                     "TOTAL_DEBT VARCHAR(200),"
                     "CURRENT_RATIO VARCHAR(200),"
                     "GROSS_PROFIT VARCHAR(200),"
                     "PROFIT_MARGIN VARCHAR(200) ,"
                     "PRIMARY KEY(STAT_TICKER) )")
except Exception as e:
    pass
try:
   mycursor.execute("DROP TABLE Profiles")
except Exception as e:
    pass
try:
   mycursor.execute("CREATE TABLE Profiles(PROF_TICKER VARCHAR(200), "
                     "NAME VARCHAR(200),"
                     "ADDRESS VARCHAR(200),"
                     "PHONENUM VARCHAR(200),"
                     "WEBSITE VARCHAR(200),"
                     "SECTOR VARCHAR(200),"
                     "INDUSTRY VARCHAR(200),"
                     "FULL_TIME VARCHAR(200),"
                     "BUS_SUMM VARCHAR(200),"
                     "PRIMARY KEY(PROF_TICKER))")
except Exception as e:
    pass
try:
    mycursor.execute("DROP TABLE Finances")

except Exception as e:
    pass
try:

    mycursor.execute("CREATE TABLE Finances(FIN_TICKER VARCHAR(200),"
                     "TOTAL_REVENUE VARCHAR(200),"
                     "COST_OF_REVENUE VARCHAR(200),"
                     "INCOME_BEFORE_TAX VARCHAR(200),"
                     "NET_INCOME VARCHAR(200),"
                     "PRIMARY KEY(FIN_TICKER))")
except Exception as e:
    pass
db.close()

